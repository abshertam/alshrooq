import 'package:flutter/material.dart';
import 'package:grouped_list/grouped_list.dart';

class CodiaPage extends StatefulWidget {
  CodiaPage({super.key});

  @override
  State<StatefulWidget> createState() => _CodiaPage();
}

class _CodiaPage extends State<CodiaPage> {
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
      child: Container(
        width: 414,
        height: 1553,
        decoration: BoxDecoration(
          color: const Color(0xffffffff),
        ),
        child: Stack(
          children: [
            Positioned(
              left: -111.291,
              width: 636.583,
              bottom: 119.23500000000001,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Expanded(
                              child: Row(
                                children: [
                                  Expanded(
                                    child: Container(
                                      height: 154,
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        mainAxisSize: MainAxisSize.max,
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Expanded(
                                            child: Column(
                                              mainAxisAlignment: MainAxisAlignment.start,
                                              mainAxisSize: MainAxisSize.max,
                                              children: [
                                                Expanded(
                                                  child: Container(
                                                    width: double.infinity,
                                                    child: Column(
                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                      mainAxisSize: MainAxisSize.max,
                                                      crossAxisAlignment: CrossAxisAlignment.end,
                                                      children: [
                                                        Row(
                                                          children: [
                                                            Expanded(
                                                              child: Row(
                                                                mainAxisAlignment: MainAxisAlignment.start,
                                                                children: [
                                                                  Expanded(
                                                                    child: Row(
                                                                      children: [
                                                                        Expanded(
                                                                          child: Container(
                                                                            height: 38,
                                                                            child: Stack(
                                                                              children: [
                                                                                Positioned(
                                                                                  left: 135.998,
                                                                                  top: 0,
                                                                                  bottom: 0,
                                                                                  child: Text(
                                                                                    'استاندات',
                                                                                    textAlign: TextAlign.left,
                                                                                    style: TextStyle(decoration: TextDecoration.none, fontSize: 24, color: const Color(0xff030303), fontFamily: 'ElMessiri-Regular', fontWeight: FontWeight.normal),
                                                                                    maxLines: 9999,
                                                                                    overflow: TextOverflow.ellipsis,
                                                                                  ),
                                                                                ),
                                                                                Positioned(
                                                                                  right: 141.58599999999996,
                                                                                  top: 4.5,
                                                                                  bottom: 8.5,
                                                                                  child: Text(
                                                                                    'See all',
                                                                                    textAlign: TextAlign.left,
                                                                                    style: TextStyle(decoration: TextDecoration.none, fontSize: 16, color: const Color(0xff104fc9), fontFamily: 'ElMessiri-Regular', fontWeight: FontWeight.normal),
                                                                                    maxLines: 9999,
                                                                                    overflow: TextOverflow.ellipsis,
                                                                                  ),
                                                                                ),
                                                                              ],
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                        const SizedBox(height: 11),
                                                        Row(
                                                          mainAxisAlignment: MainAxisAlignment.start,
                                                          children: [
                                                            SizedBox(
                                                              width: 500.585,
                                                              height: 105,
                                                              child: Row(
                                                                mainAxisAlignment: MainAxisAlignment.end,
                                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                                children: [
                                                                  Expanded(
                                                                    child: Column(
                                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                                      mainAxisSize: MainAxisSize.max,
                                                                      children: [
                                                                        Expanded(
                                                                          child: Container(
                                                                            width: double.infinity,
                                                                            decoration: BoxDecoration(
                                                                              color: const Color(0xfff8a44c),
                                                                              borderRadius: BorderRadius.circular(18),
                                                                            ),
                                                                            child: Stack(
                                                                              children: [
                                                                                Positioned(
                                                                                  left: 103.842,
                                                                                  top: 40,
                                                                                  child: Text(
                                                                                    'أكلريك',
                                                                                    textAlign: TextAlign.left,
                                                                                    style: TextStyle(decoration: TextDecoration.none, fontSize: 20, color: const Color(0xff3e423f), fontFamily: 'ElMessiri-Regular', fontWeight: FontWeight.normal),
                                                                                    maxLines: 9999,
                                                                                    overflow: TextOverflow.ellipsis,
                                                                                  ),
                                                                                ),
                                                                                Positioned(
                                                                                  left: 14.241,
                                                                                  width: 71.898,
                                                                                  top: 15.745,
                                                                                  height: 61.955,
                                                                                  child: Image.asset('images/imagePulsesPng_66033.png', width: 71.898, height: 61.955, fit: BoxFit.fill,),
                                                                                ),
                                                                              ],
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                  const SizedBox(width: 14.949951171875),
                                                                  Column(
                                                                    children: [
                                                                      Expanded(
                                                                        child: Column(
                                                                          mainAxisAlignment: MainAxisAlignment.start,
                                                                          children: [
                                                                            Expanded(
                                                                              child: Column(
                                                                                children: [
                                                                                  Expanded(
                                                                                    child: Container(
                                                                                      width: 237.449,
                                                                                      decoration: BoxDecoration(
                                                                                        color: const Color(0xff53b175),
                                                                                        borderRadius: BorderRadius.circular(18),
                                                                                      ),
                                                                                      child: Stack(
                                                                                        children: [
                                                                                          Positioned(
                                                                                            left: 104.157,
                                                                                            top: 40,
                                                                                            child: Text(
                                                                                              'فوركس',
                                                                                              textAlign: TextAlign.left,
                                                                                              style: TextStyle(decoration: TextDecoration.none, fontSize: 20, color: const Color(0xff3d413f), fontFamily: 'ElMessiri-Regular', fontWeight: FontWeight.normal),
                                                                                              maxLines: 9999,
                                                                                              overflow: TextOverflow.ellipsis,
                                                                                            ),
                                                                                          ),
                                                                                          Positioned(
                                                                                            left: 18.104,
                                                                                            width: 50.053,
                                                                                            top: 16.745,
                                                                                            height: 60.983,
                                                                                            child: Image.asset('images/imageSackOfRice_66037.png', width: 50.053, height: 60.983, fit: BoxFit.fill,),
                                                                                          ),
                                                                                        ],
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                            ),
                                                                          ],
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 19.9998779296875),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      SizedBox(
                        width: 361.65,
                        height: 248.51,
                        child: Padding(
                          padding: const EdgeInsets.only(left: 0, top: 0, right: 0.0000152587890625, bottom: 0),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Expanded(
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  mainAxisSize: MainAxisSize.max,
                                  children: [
                                    Expanded(
                                      child: Container(
                                        width: double.infinity,
                                        decoration: BoxDecoration(
                                          border: Border.all(color: const Color(0xffe2e2e2), width: 1),
                                          borderRadius: BorderRadius.circular(18),
                                          boxShadow: const [BoxShadow(color: const Color(0x00000000), offset: Offset(0, 6), blurRadius: 12),],
                                        ),
                                        child: Padding(
                                          padding: const EdgeInsets.only(left: 6.0840301513671875, top: 0, right: 6.0840301513671875, bottom: 14.997665405273438),
                                          child: Column(
                                            mainAxisAlignment: MainAxisAlignment.end,
                                            mainAxisSize: MainAxisSize.max,
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children: [
                                              Row(
                                                children: [
                                                  Expanded(
                                                    child: Row(
                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                      children: [
                                                        Expanded(
                                                          child: Row(
                                                            children: [
                                                              Expanded(
                                                                child: Container(
                                                                  height: 210.767,
                                                                  child: Column(
                                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                                    crossAxisAlignment: CrossAxisAlignment.center,
                                                                    children: [
                                                                      Row(
                                                                        mainAxisAlignment: MainAxisAlignment.center,
                                                                        children: [
                                                                          Image.asset('images/imagePngfuel_66047.png', width: 100, height: 77, fit: BoxFit.fill,),
                                                                        ],
                                                                      ),
                                                                      const SizedBox(height: 25),
                                                                      Row(
                                                                        mainAxisAlignment: MainAxisAlignment.center,
                                                                        children: [
                                                                          SizedBox(
                                                                            width: 161.157,
                                                                            height: 108.767,
                                                                            child: Stack(
                                                                              children: [
                                                                                Positioned(
                                                                                  left: 0,
                                                                                  right: 7.915999999999997,
                                                                                  bottom: 0,
                                                                                  height: 45.668,
                                                                                  child: Stack(
                                                                                    children: [
                                                                                      Positioned(
                                                                                        left: 9.916,
                                                                                        top: 16.798,
                                                                                        bottom: 10.870000000000001,
                                                                                        child: Text(
                                                                                          '15 KW',
                                                                                          textAlign: TextAlign.left,
                                                                                          style: TextStyle(decoration: TextDecoration.none, fontSize: 18, color: const Color(0xff181725), fontFamily: 'ElMessiri-Regular', fontWeight: FontWeight.normal),
                                                                                          maxLines: 9999,
                                                                                          overflow: TextOverflow.ellipsis,
                                                                                        ),
                                                                                      ),
                                                                                      Positioned(
                                                                                        right: 1.4210854715202004e-14,
                                                                                        width: 45.67,
                                                                                        top: 0,
                                                                                        height: 45.668,
                                                                                        child: Image.asset('images/imageGroup_660336.png', width: 45.67, height: 45.668,),
                                                                                      ),
                                                                                    ],
                                                                                  ),
                                                                                ),
                                                                                Positioned(
                                                                                  left: 9.157,
                                                                                  width: 152,
                                                                                  top: 0,
                                                                                  child: Column(
                                                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                                                    mainAxisSize: MainAxisSize.min,
                                                                                    crossAxisAlignment: CrossAxisAlignment.start,
                                                                                    children: [
                                                                                      Row(
                                                                                        children: [
                                                                                          Expanded(
                                                                                            child: Row(
                                                                                              mainAxisAlignment: MainAxisAlignment.start,
                                                                                              mainAxisSize: MainAxisSize.min,
                                                                                              children: [
                                                                                                Expanded(
                                                                                                  child: Container(
                                                                                                    child: Text(
                                                                                                      'استاند اكلريك بتصميم خاص',
                                                                                                      textAlign: TextAlign.right,
                                                                                                      style: TextStyle(decoration: TextDecoration.none, fontSize: 13, color: const Color(0xff181725), fontFamily: 'ElMessiri-Regular', fontWeight: FontWeight.normal),
                                                                                                      maxLines: 9999,
                                                                                                      overflow: TextOverflow.ellipsis,
                                                                                                    ),
                                                                                                  ),
                                                                                                ),
                                                                                              ],
                                                                                            ),
                                                                                          ),
                                                                                        ],
                                                                                      ),
                                                                                      const SizedBox(height: 10),
                                                                                      Row(
                                                                                        mainAxisAlignment: MainAxisAlignment.start,
                                                                                        children: [
                                                                                          SizedBox(
                                                                                            width: 83,
                                                                                            height: 15,
                                                                                            child: Text(
                                                                                              'مقاس 30*20',
                                                                                              textAlign: TextAlign.left,
                                                                                              style: TextStyle(decoration: TextDecoration.none, fontSize: 14, color: const Color(0xff7c7c7c), fontFamily: 'ElMessiri-Regular', fontWeight: FontWeight.normal),
                                                                                              maxLines: 9999,
                                                                                              overflow: TextOverflow.ellipsis,
                                                                                            ),
                                                                                          ),
                                                                                        ],
                                                                                      ),
                                                                                    ],
                                                                                  ),
                                                                                ),
                                                                              ],
                                                                            ),
                                                                          ),
                                                                        ],
                                                                      ),
                                                                    ],
                                                                  ),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(width: 14.999954223632812),
                              Expanded(
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  mainAxisSize: MainAxisSize.max,
                                  children: [
                                    Expanded(
                                      child: Container(
                                        width: double.infinity,
                                        decoration: BoxDecoration(
                                          border: Border.all(color: const Color(0xffe2e2e2), width: 1),
                                          borderRadius: BorderRadius.circular(18),
                                          boxShadow: const [BoxShadow(color: const Color(0x00000000), offset: Offset(0, 6), blurRadius: 12),],
                                        ),
                                        child: Stack(
                                          children: [
                                            Positioned(
                                              left: 28.916,
                                              width: 138.023,
                                              top: 10.745,
                                              child: Padding(
                                                padding: const EdgeInsets.only(left: 0, top: 0, right: 1, bottom: 0),
                                                child: Column(
                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                  mainAxisSize: MainAxisSize.min,
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Row(
                                                      children: [
                                                        Expanded(
                                                          child: Row(
                                                            mainAxisAlignment: MainAxisAlignment.start,
                                                            children: [
                                                              Expanded(
                                                                child: Row(
                                                                  children: [
                                                                    Expanded(
                                                                      child: Container(
                                                                        child: Image.asset('images/containerFrame_660335.png', height: 114,),
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                    Row(
                                                      children: [
                                                        Expanded(
                                                          child: Row(
                                                            mainAxisAlignment: MainAxisAlignment.start,
                                                            mainAxisSize: MainAxisSize.min,
                                                            children: [
                                                              Expanded(
                                                                child: Container(
                                                                  child: Text(
                                                                    'استاند فوركس مزدوج',
                                                                    textAlign: TextAlign.right,
                                                                    style: TextStyle(decoration: TextDecoration.none, fontSize: 14, color: const Color(0xff181725), fontFamily: 'ElMessiri-Regular', fontWeight: FontWeight.normal),
                                                                    maxLines: 9999,
                                                                    overflow: TextOverflow.ellipsis,
                                                                  ),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                            Positioned(
                                              left: 6.386,
                                              right: 10,
                                              top: 152.745,
                                              height: 80.767,
                                              child: Stack(
                                                children: [
                                                  Positioned(
                                                    left: 8.53,
                                                    width: 88,
                                                    top: 0,
                                                    height: 15,
                                                    child: Text(
                                                      'مقاس 30*120',
                                                      textAlign: TextAlign.left,
                                                      style: TextStyle(decoration: TextDecoration.none, fontSize: 14, color: const Color(0xff7c7c7c), fontFamily: 'ElMessiri-Regular', fontWeight: FontWeight.normal),
                                                      maxLines: 9999,
                                                      overflow: TextOverflow.ellipsis,
                                                    ),
                                                  ),
                                                  Positioned(
                                                    left: 4,
                                                    right: 4,
                                                    top: 35.099,
                                                    bottom: 0,
                                                    child: Stack(
                                                      children: [
                                                        Positioned(
                                                          left: 4.614,
                                                          top: 16.798,
                                                          bottom: 10.870000000000001,
                                                          child: Text(
                                                            '25 KW',
                                                            textAlign: TextAlign.left,
                                                            style: TextStyle(decoration: TextDecoration.none, fontSize: 18, color: const Color(0xff181725), fontFamily: 'ElMessiri-Regular', fontWeight: FontWeight.normal),
                                                            maxLines: 9999,
                                                            overflow: TextOverflow.ellipsis,
                                                          ),
                                                        ),
                                                        Positioned(
                                                          right: -1.4210854715202004e-14,
                                                          width: 45.67,
                                                          top: 0,
                                                          height: 45.668,
                                                          child: Image.asset('images/imageGroup_660337.png', width: 45.67, height: 45.668,),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            Positioned(
              left: -111.291,
              width: 636.583,
              top: 42,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Expanded(
                              child: Row(
                                children: [
                                  Expanded(
                                    child: Container(
                                      height: 679.462,
                                      child: Column(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Row(
                                            children: [
                                              Expanded(
                                                child: Row(
                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                  children: [
                                                    Expanded(
                                                      child: Row(
                                                        children: [
                                                          Expanded(
                                                            child: Container(
                                                              height: 679.462,
                                                              child: Column(
                                                                mainAxisAlignment: MainAxisAlignment.start,
                                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                                children: [
                                                                  Row(
                                                                    mainAxisAlignment: MainAxisAlignment.center,
                                                                    children: [
                                                                      Image.asset('images/imageHiroTransparent_660155.png', width: 66, height: 48, fit: BoxFit.cover,),
                                                                    ],
                                                                  ),
                                                                  const SizedBox(height: 8),
                                                                  Row(
                                                                    children: [
                                                                      Expanded(
                                                                        child: Row(
                                                                          mainAxisAlignment: MainAxisAlignment.start,
                                                                          children: [
                                                                            Expanded(
                                                                              child: Row(
                                                                                children: [
                                                                                  Expanded(
                                                                                    child: Container(
                                                                                      height: 623.462,
                                                                                      child: Column(
                                                                                        mainAxisAlignment: MainAxisAlignment.start,
                                                                                        crossAxisAlignment: CrossAxisAlignment.center,
                                                                                        children: [
                                                                                          Row(
                                                                                            children: [
                                                                                              Expanded(
                                                                                                child: Row(
                                                                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                                                                  children: [
                                                                                                    Expanded(
                                                                                                      child: Row(
                                                                                                        children: [
                                                                                                          Expanded(
                                                                                                            child: Container(
                                                                                                              height: 28,
                                                                                                              child: Padding(
                                                                                                                padding: const EdgeInsets.only(left: 0, top: 0, right: 209.4246826171875, bottom: 0),
                                                                                                                child: Row(
                                                                                                                  mainAxisAlignment: MainAxisAlignment.end,
                                                                                                                  mainAxisSize: MainAxisSize.max,
                                                                                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                                                                                  children: [
                                                                                                                    const SizedBox(width: 10.000005722045898),
                                                                                                                    Column(
                                                                                                                      mainAxisAlignment: MainAxisAlignment.center,
                                                                                                                      children: [
                                                                                                                        SizedBox(
                                                                                                                          width: 103.787,
                                                                                                                          child: Text(
                                                                                                                            'Jahra, Jahra',
                                                                                                                            textAlign: TextAlign.center,
                                                                                                                            style: TextStyle(decoration: TextDecoration.none, fontSize: 18, color: const Color(0xff4c4e4d), fontFamily: 'ElMessiri-Regular', fontWeight: FontWeight.normal),
                                                                                                                            maxLines: 9999,
                                                                                                                            overflow: TextOverflow.ellipsis,
                                                                                                                          ),
                                                                                                                        ),
                                                                                                                      ],
                                                                                                                    ),
                                                                                                                  ],
                                                                                                                ),
                                                                                                              ),
                                                                                                            ),
                                                                                                          ),
                                                                                                        ],
                                                                                                      ),
                                                                                                    ),
                                                                                                  ],
                                                                                                ),
                                                                                              ),
                                                                                            ],
                                                                                          ),
                                                                                          const SizedBox(height: 13.38946533203125),
                                                                                          Row(
                                                                                            children: [
                                                                                              Expanded(
                                                                                                child: Row(
                                                                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                                                                  children: [
                                                                                                    Expanded(
                                                                                                      child: Row(
                                                                                                        children: [
                                                                                                          Expanded(
                                                                                                            child: Container(
                                                                                                              height: 582.072,
                                                                                                              child: Column(
                                                                                                                mainAxisAlignment: MainAxisAlignment.start,
                                                                                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                                                                                children: [
                                                                                                                  Row(
                                                                                                                    mainAxisAlignment: MainAxisAlignment.center,
                                                                                                                    children: [
                                                                                                                      Container(
                                                                                                                        width: 364,
                                                                                                                        height: 51.568,
                                                                                                                        decoration: BoxDecoration(
                                                                                                                          color: const Color(0xfff1f2f2),
                                                                                                                          borderRadius: BorderRadius.circular(15),
                                                                                                                        ),
                                                                                                                        child: Padding(
                                                                                                                          padding: const EdgeInsets.only(left: 15, top: 14.61053466796875, right: 0, bottom: 14.957866668701172),
                                                                                                                          child: Row(
                                                                                                                            mainAxisAlignment: MainAxisAlignment.start,
                                                                                                                            crossAxisAlignment: CrossAxisAlignment.center,
                                                                                                                            children: [
                                                                                                                              Column(
                                                                                                                                mainAxisAlignment: MainAxisAlignment.center,
                                                                                                                                children: [
                                                                                                                                  Image.asset('images/imageVector_660111.png', width: 18.205, height: 18.205,),
                                                                                                                                ],
                                                                                                                              ),
                                                                                                                              Column(
                                                                                                                                mainAxisAlignment: MainAxisAlignment.center,
                                                                                                                                children: [
                                                                                                                                  SizedBox(
                                                                                                                                    width: 47.071,
                                                                                                                                    child: Text(
                                                                                                                                      'بحث',
                                                                                                                                      textAlign: TextAlign.center,
                                                                                                                                      style: TextStyle(decoration: TextDecoration.none, fontSize: 14, color: const Color(0xff7c7c7c), fontFamily: 'ElMessiri-Regular', fontWeight: FontWeight.normal),
                                                                                                                                      maxLines: 9999,
                                                                                                                                      overflow: TextOverflow.ellipsis,
                                                                                                                                    ),
                                                                                                                                  ),
                                                                                                                                ],
                                                                                                                              ),
                                                                                                                            ],
                                                                                                                          ),
                                                                                                                        ),
                                                                                                                      ),
                                                                                                                    ],
                                                                                                                  ),
                                                                                                                  const SizedBox(height: 20.000019073486328),
                                                                                                                  Row(
                                                                                                                    children: [
                                                                                                                      Expanded(
                                                                                                                        child: Row(
                                                                                                                          mainAxisAlignment: MainAxisAlignment.start,
                                                                                                                          children: [
                                                                                                                            Expanded(
                                                                                                                              child: Row(
                                                                                                                                children: [
                                                                                                                                  Expanded(
                                                                                                                                    child: Container(
                                                                                                                                      height: 510.504,
                                                                                                                                      child: Column(
                                                                                                                                        mainAxisAlignment: MainAxisAlignment.start,
                                                                                                                                        crossAxisAlignment: CrossAxisAlignment.center,
                                                                                                                                        children: [
                                                                                                                                          Row(
                                                                                                                                            mainAxisAlignment: MainAxisAlignment.center,
                                                                                                                                            children: [
                                                                                                                                              SizedBox(
                                                                                                                                                width: 368.203,
                                                                                                                                                height: 114.994,
                                                                                                                                                child: Stack(
                                                                                                                                                  children: [
                                                                                                                                                    Positioned(
                                                                                                                                                      left: 0,
                                                                                                                                                      right: 0,
                                                                                                                                                      top: 0,
                                                                                                                                                      bottom: 0,
                                                                                                                                                      child: Image.asset('images/imageMaskGroupImg1_660203.png', fit: BoxFit.cover,),
                                                                                                                                                    ),
                                                                                                                                                    Positioned(
                                                                                                                                                      left: 0,
                                                                                                                                                      right: 0,
                                                                                                                                                      top: 0,
                                                                                                                                                      bottom: 0,
                                                                                                                                                      child: Image.asset('images/imageMaskGroup_660339.png',),
                                                                                                                                                    ),
                                                                                                                                                    Positioned(
                                                                                                                                                      left: 164.183,
                                                                                                                                                      width: 41.04,
                                                                                                                                                      bottom: 7.048999999999998,
                                                                                                                                                      height: 5.379,
                                                                                                                                                      child: Image.asset('images/imageGroup_660340.png', width: 41.04, height: 5.379,),
                                                                                                                                                    ),
                                                                                                                                                    Positioned(
                                                                                                                                                      left: 0,
                                                                                                                                                      right: 0,
                                                                                                                                                      top: 0,
                                                                                                                                                      bottom: 0,
                                                                                                                                                      child: Image.asset('images/imageMaskGroupImg2_660211.png', fit: BoxFit.cover,),
                                                                                                                                                    ),
                                                                                                                                                    Positioned(
                                                                                                                                                      left: 5.629,
                                                                                                                                                      width: 122.359,
                                                                                                                                                      top: 2.907,
                                                                                                                                                      bottom: 6.963999999999999,
                                                                                                                                                      child: Image.asset('images/imageEmpty_66077.png', width: 122.359, fit: BoxFit.cover,),
                                                                                                                                                    ),
                                                                                                                                                    Positioned(
                                                                                                                                                      left: 0,
                                                                                                                                                      width: 204.98,
                                                                                                                                                      top: 0,
                                                                                                                                                      bottom: 0,
                                                                                                                                                      child: Image.asset('images/imageRectangle_66078.png', width: 204.98,),
                                                                                                                                                    ),
                                                                                                                                                  ],
                                                                                                                                                ),
                                                                                                                                              ),
                                                                                                                                            ],
                                                                                                                                          ),
                                                                                                                                          const SizedBox(height: 29.999969482421875),
                                                                                                                                          Row(
                                                                                                                                            children: [
                                                                                                                                              Expanded(
                                                                                                                                                child: Row(
                                                                                                                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                                                                                                                  children: [
                                                                                                                                                    Expanded(
                                                                                                                                                      child: Row(
                                                                                                                                                        children: [
                                                                                                                                                          Expanded(
                                                                                                                                                            child: Container(
                                                                                                                                                              height: 297.51,
                                                                                                                                                              child: Column(
                                                                                                                                                                mainAxisAlignment: MainAxisAlignment.start,
                                                                                                                                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                                                                                                                                children: [
                                                                                                                                                                  Row(
                                                                                                                                                                    children: [
                                                                                                                                                                      Expanded(
                                                                                                                                                                        child: Row(
                                                                                                                                                                          mainAxisAlignment: MainAxisAlignment.start,
                                                                                                                                                                          children: [
                                                                                                                                                                            Expanded(
                                                                                                                                                                              child: Row(
                                                                                                                                                                                children: [
                                                                                                                                                                                  Expanded(
                                                                                                                                                                                    child: Container(
                                                                                                                                                                                      height: 38,
                                                                                                                                                                                      child: Stack(
                                                                                                                                                                                        children: [
                                                                                                                                                                                          Positioned(
                                                                                                                                                                                            left: 65.998,
                                                                                                                                                                                            top: 0,
                                                                                                                                                                                            bottom: 0,
                                                                                                                                                                                            child: Text(
                                                                                                                                                                                              'تعليقات ماي',
                                                                                                                                                                                              textAlign: TextAlign.left,
                                                                                                                                                                                              style: TextStyle(decoration: TextDecoration.none, fontSize: 24, color: const Color(0xff181725), fontFamily: 'ElMessiri-Regular', fontWeight: FontWeight.normal),
                                                                                                                                                                                              maxLines: 9999,
                                                                                                                                                                                              overflow: TextOverflow.ellipsis,
                                                                                                                                                                                            ),
                                                                                                                                                                                          ),
                                                                                                                                                                                          Positioned(
                                                                                                                                                                                            left: 379.997,
                                                                                                                                                                                            top: 4.5,
                                                                                                                                                                                            bottom: 8.5,
                                                                                                                                                                                            child: Text(
                                                                                                                                                                                              'See all',
                                                                                                                                                                                              textAlign: TextAlign.left,
                                                                                                                                                                                              style: TextStyle(decoration: TextDecoration.none, fontSize: 16, color: const Color(0xff104fc9), fontFamily: 'ElMessiri-Regular', fontWeight: FontWeight.normal),
                                                                                                                                                                                              maxLines: 9999,
                                                                                                                                                                                              overflow: TextOverflow.ellipsis,
                                                                                                                                                                                            ),
                                                                                                                                                                                          ),
                                                                                                                                                                                        ],
                                                                                                                                                                                      ),
                                                                                                                                                                                    ),
                                                                                                                                                                                  ),
                                                                                                                                                                                ],
                                                                                                                                                                              ),
                                                                                                                                                                            ),
                                                                                                                                                                          ],
                                                                                                                                                                        ),
                                                                                                                                                                      ),
                                                                                                                                                                    ],
                                                                                                                                                                  ),
                                                                                                                                                                  const SizedBox(height: 11.00006103515625),
                                                                                                                                                                  Row(
                                                                                                                                                                    children: [
                                                                                                                                                                      Expanded(
                                                                                                                                                                        child: Row(
                                                                                                                                                                          mainAxisAlignment: MainAxisAlignment.start,
                                                                                                                                                                          children: [
                                                                                                                                                                            Expanded(
                                                                                                                                                                              child: Row(
                                                                                                                                                                                children: [
                                                                                                                                                                                  Expanded(
                                                                                                                                                                                    child: Container(
                                                                                                                                                                                      height: 248.51,
                                                                                                                                                                                      child: Padding(
                                                                                                                                                                                        padding: const EdgeInsets.only(left: 0, top: 0, right: 10, bottom: 0),
                                                                                                                                                                                        child: Row(
                                                                                                                                                                                          mainAxisAlignment: MainAxisAlignment.end,
                                                                                                                                                                                          mainAxisSize: MainAxisSize.max,
                                                                                                                                                                                          crossAxisAlignment: CrossAxisAlignment.center,
                                                                                                                                                                                          children: [
                                                                                                                                                                                            Column(
                                                                                                                                                                                              children: [
                                                                                                                                                                                                Expanded(
                                                                                                                                                                                                  child: Column(
                                                                                                                                                                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                                                                                                                                                                    children: [
                                                                                                                                                                                                      Expanded(
                                                                                                                                                                                                        child: Column(
                                                                                                                                                                                                          children: [
                                                                                                                                                                                                            Expanded(
                                                                                                                                                                                                              child: Container(
                                                                                                                                                                                                                width: 173.325,
                                                                                                                                                                                                                decoration: BoxDecoration(
                                                                                                                                                                                                                  border: Border.all(color: const Color(0xffe2e2e2), width: 1),
                                                                                                                                                                                                                  borderRadius: BorderRadius.circular(18),
                                                                                                                                                                                                                  boxShadow: const [BoxShadow(color: const Color(0x00000000), offset: Offset(0, 6), blurRadius: 12),],
                                                                                                                                                                                                                ),
                                                                                                                                                                                                                child: Padding(
                                                                                                                                                                                                                  padding: const EdgeInsets.only(left: 6.4377899169921875, top: 0.0507354736328125, right: 6.4377899169921875, bottom: 0),
                                                                                                                                                                                                                  child: Column(
                                                                                                                                                                                                                    mainAxisAlignment: MainAxisAlignment.center,
                                                                                                                                                                                                                    mainAxisSize: MainAxisSize.max,
                                                                                                                                                                                                                    crossAxisAlignment: CrossAxisAlignment.center,
                                                                                                                                                                                                                    children: [
                                                                                                                                                                                                                      Row(
                                                                                                                                                                                                                        children: [
                                                                                                                                                                                                                          Expanded(
                                                                                                                                                                                                                            child: Row(
                                                                                                                                                                                                                              mainAxisAlignment: MainAxisAlignment.start,
                                                                                                                                                                                                                              children: [
                                                                                                                                                                                                                                Expanded(
                                                                                                                                                                                                                                  child: Row(
                                                                                                                                                                                                                                    children: [
                                                                                                                                                                                                                                      Expanded(
                                                                                                                                                                                                                                        child: Container(
                                                                                                                                                                                                                                          height: 218.464,
                                                                                                                                                                                                                                          child: Column(
                                                                                                                                                                                                                                            mainAxisAlignment: MainAxisAlignment.start,
                                                                                                                                                                                                                                            crossAxisAlignment: CrossAxisAlignment.center,
                                                                                                                                                                                                                                            children: [
                                                                                                                                                                                                                                              Row(
                                                                                                                                                                                                                                                mainAxisAlignment: MainAxisAlignment.center,
                                                                                                                                                                                                                                                children: [
                                                                                                                                                                                                                                                  Image.asset('images/imageFeadccebdcdbfbR_660197.png', width: 99.887, height: 99.789, fit: BoxFit.cover,),
                                                                                                                                                                                                                                                ],
                                                                                                                                                                                                                                              ),
                                                                                                                                                                                                                                              const SizedBox(height: 7.211143493652344),
                                                                                                                                                                                                                                              Row(
                                                                                                                                                                                                                                                mainAxisAlignment: MainAxisAlignment.center,
                                                                                                                                                                                                                                                children: [
                                                                                                                                                                                                                                                  SizedBox(
                                                                                                                                                                                                                                                    width: 160.45,
                                                                                                                                                                                                                                                    height: 111.464,
                                                                                                                                                                                                                                                    child: Padding(
                                                                                                                                                                                                                                                      padding: const EdgeInsets.only(left: 0, top: 0, right: 0.0000457763671875, bottom: 0),
                                                                                                                                                                                                                                                      child: Column(
                                                                                                                                                                                                                                                        mainAxisAlignment: MainAxisAlignment.start,
                                                                                                                                                                                                                                                        crossAxisAlignment: CrossAxisAlignment.end,
                                                                                                                                                                                                                                                        children: [
                                                                                                                                                                                                                                                          Row(
                                                                                                                                                                                                                                                            children: [
                                                                                                                                                                                                                                                              Expanded(
                                                                                                                                                                                                                                                                child: Row(
                                                                                                                                                                                                                                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                                                                                                                                                                                                                                  mainAxisSize: MainAxisSize.min,
                                                                                                                                                                                                                                                                  children: [
                                                                                                                                                                                                                                                                    Expanded(
                                                                                                                                                                                                                                                                      child: Container(
                                                                                                                                                                                                                                                                        child: Text(
                                                                                                                                                                                                                                                                          'كرتون ماي أبراج مع ثيم خاص',
                                                                                                                                                                                                                                                                          textAlign: TextAlign.right,
                                                                                                                                                                                                                                                                          style: TextStyle(decoration: TextDecoration.none, fontSize: 13, color: const Color(0xff181725), fontFamily: 'ElMessiri-Regular', fontWeight: FontWeight.normal),
                                                                                                                                                                                                                                                                          maxLines: 9999,
                                                                                                                                                                                                                                                                          overflow: TextOverflow.ellipsis,
                                                                                                                                                                                                                                                                        ),
                                                                                                                                                                                                                                                                      ),
                                                                                                                                                                                                                                                                    ),
                                                                                                                                                                                                                                                                  ],
                                                                                                                                                                                                                                                                ),
                                                                                                                                                                                                                                                              ),
                                                                                                                                                                                                                                                            ],
                                                                                                                                                                                                                                                          ),
                                                                                                                                                                                                                                                          const SizedBox(height: 13),
                                                                                                                                                                                                                                                          Row(
                                                                                                                                                                                                                                                            children: [
                                                                                                                                                                                                                                                              Expanded(
                                                                                                                                                                                                                                                                child: Row(
                                                                                                                                                                                                                                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                                                                                                                                                                                                                                  children: [
                                                                                                                                                                                                                                                                    Expanded(
                                                                                                                                                                                                                                                                      child: Row(
                                                                                                                                                                                                                                                                        children: [
                                                                                                                                                                                                                                                                          Expanded(
                                                                                                                                                                                                                                                                            child: Container(
                                                                                                                                                                                                                                                                              height: 80.464,
                                                                                                                                                                                                                                                                              child: Padding(
                                                                                                                                                                                                                                                                                padding: const EdgeInsets.only(left: 7.5621337890625, top: 0, right: 7.5621337890625, bottom: 0),
                                                                                                                                                                                                                                                                                child: Column(
                                                                                                                                                                                                                                                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                                                                                                                                                                                                                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                                                                                                                                                                                                                                                  children: [
                                                                                                                                                                                                                                                                                    Row(
                                                                                                                                                                                                                                                                                      children: [
                                                                                                                                                                                                                                                                                        Expanded(
                                                                                                                                                                                                                                                                                          child: Row(
                                                                                                                                                                                                                                                                                            mainAxisAlignment: MainAxisAlignment.start,
                                                                                                                                                                                                                                                                                            mainAxisSize: MainAxisSize.min,
                                                                                                                                                                                                                                                                                            children: [
                                                                                                                                                                                                                                                                                              Expanded(
                                                                                                                                                                                                                                                                                                child: Container(
                                                                                                                                                                                                                                                                                                  child: Text(
                                                                                                                                                                                                                                                                                                    '20 حبة',
                                                                                                                                                                                                                                                                                                    textAlign: TextAlign.left,
                                                                                                                                                                                                                                                                                                    style: TextStyle(decoration: TextDecoration.none, fontSize: 14, color: const Color(0xff7c7c7c), fontFamily: 'ElMessiri-Regular', fontWeight: FontWeight.normal),
                                                                                                                                                                                                                                                                                                    maxLines: 9999,
                                                                                                                                                                                                                                                                                                    overflow: TextOverflow.ellipsis,
                                                                                                                                                                                                                                                                                                  ),
                                                                                                                                                                                                                                                                                                ),
                                                                                                                                                                                                                                                                                              ),
                                                                                                                                                                                                                                                                                            ],
                                                                                                                                                                                                                                                                                          ),
                                                                                                                                                                                                                                                                                        ),
                                                                                                                                                                                                                                                                                      ],
                                                                                                                                                                                                                                                                                    ),
                                                                                                                                                                                                                                                                                    const SizedBox(height: 19.902671813964844),
                                                                                                                                                                                                                                                                                    Row(
                                                                                                                                                                                                                                                                                      children: [
                                                                                                                                                                                                                                                                                        Expanded(
                                                                                                                                                                                                                                                                                          child: Row(
                                                                                                                                                                                                                                                                                            mainAxisAlignment: MainAxisAlignment.start,
                                                                                                                                                                                                                                                                                            children: [
                                                                                                                                                                                                                                                                                              Expanded(
                                                                                                                                                                                                                                                                                                child: Row(
                                                                                                                                                                                                                                                                                                  children: [
                                                                                                                                                                                                                                                                                                    Expanded(
                                                                                                                                                                                                                                                                                                      child: Container(
                                                                                                                                                                                                                                                                                                        height: 45.668,
                                                                                                                                                                                                                                                                                                        child: Stack(
                                                                                                                                                                                                                                                                                                          children: [
                                                                                                                                                                                                                                                                                                            Positioned(
                                                                                                                                                                                                                                                                                                              right: -1.4210854715202004e-14,
                                                                                                                                                                                                                                                                                                              width: 45.67,
                                                                                                                                                                                                                                                                                                              top: 0,
                                                                                                                                                                                                                                                                                                              height: 45.668,
                                                                                                                                                                                                                                                                                                              child: Image.asset('images/imageImageview_660341.png', width: 45.67, height: 45.668,),
                                                                                                                                                                                                                                                                                                            ),
                                                                                                                                                                                                                                                                                                            Positioned(
                                                                                                                                                                                                                                                                                                              left: 0,
                                                                                                                                                                                                                                                                                                              top: 17.205,
                                                                                                                                                                                                                                                                                                              bottom: 10.463000000000001,
                                                                                                                                                                                                                                                                                                              child: Text(
                                                                                                                                                                                                                                                                                                                '5 KW',
                                                                                                                                                                                                                                                                                                                textAlign: TextAlign.left,
                                                                                                                                                                                                                                                                                                                style: TextStyle(decoration: TextDecoration.none, fontSize: 18, color: const Color(0xff181725), fontFamily: 'ElMessiri-Regular', fontWeight: FontWeight.normal),
                                                                                                                                                                                                                                                                                                                maxLines: 9999,
                                                                                                                                                                                                                                                                                                                overflow: TextOverflow.ellipsis,
                                                                                                                                                                                                                                                                                                              ),
                                                                                                                                                                                                                                                                                                            ),
                                                                                                                                                                                                                                                                                                          ],
                                                                                                                                                                                                                                                                                                        ),
                                                                                                                                                                                                                                                                                                      ),
                                                                                                                                                                                                                                                                                                    ),
                                                                                                                                                                                                                                                                                                  ],
                                                                                                                                                                                                                                                                                                ),
                                                                                                                                                                                                                                                                                              ),
                                                                                                                                                                                                                                                                                            ],
                                                                                                                                                                                                                                                                                          ),
                                                                                                                                                                                                                                                                                        ),
                                                                                                                                                                                                                                                                                      ],
                                                                                                                                                                                                                                                                                    ),
                                                                                                                                                                                                                                                                                  ],
                                                                                                                                                                                                                                                                                ),
                                                                                                                                                                                                                                                                              ),
                                                                                                                                                                                                                                                                            ),
                                                                                                                                                                                                                                                                          ),
                                                                                                                                                                                                                                                                        ],
                                                                                                                                                                                                                                                                      ),
                                                                                                                                                                                                                                                                    ),
                                                                                                                                                                                                                                                                  ],
                                                                                                                                                                                                                                                                ),
                                                                                                                                                                                                                                                              ),
                                                                                                                                                                                                                                                            ],
                                                                                                                                                                                                                                                          ),
                                                                                                                                                                                                                                                        ],
                                                                                                                                                                                                                                                      ),
                                                                                                                                                                                                                                                    ),
                                                                                                                                                                                                                                                  ),
                                                                                                                                                                                                                                                ],
                                                                                                                                                                                                                                              ),
                                                                                                                                                                                                                                            ],
                                                                                                                                                                                                                                          ),
                                                                                                                                                                                                                                        ),
                                                                                                                                                                                                                                      ),
                                                                                                                                                                                                                                    ],
                                                                                                                                                                                                                                  ),
                                                                                                                                                                                                                                ),
                                                                                                                                                                                                                              ],
                                                                                                                                                                                                                            ),
                                                                                                                                                                                                                          ),
                                                                                                                                                                                                                        ],
                                                                                                                                                                                                                      ),
                                                                                                                                                                                                                    ],
                                                                                                                                                                                                                  ),
                                                                                                                                                                                                                ),
                                                                                                                                                                                                              ),
                                                                                                                                                                                                            ),
                                                                                                                                                                                                          ],
                                                                                                                                                                                                        ),
                                                                                                                                                                                                      ),
                                                                                                                                                                                                    ],
                                                                                                                                                                                                  ),
                                                                                                                                                                                                ),
                                                                                                                                                                                              ],
                                                                                                                                                                                            ),
                                                                                                                                                                                            const SizedBox(width: 10),
                                                                                                                                                                                            Column(
                                                                                                                                                                                              children: [
                                                                                                                                                                                                Expanded(
                                                                                                                                                                                                  child: Column(
                                                                                                                                                                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                                                                                                                                                                    children: [
                                                                                                                                                                                                      Expanded(
                                                                                                                                                                                                        child: Column(
                                                                                                                                                                                                          children: [
                                                                                                                                                                                                            Expanded(
                                                                                                                                                                                                              child: Container(
                                                                                                                                                                                                                width: 236.906,
                                                                                                                                                                                                                child: Stack(
                                                                                                                                                                                                                  children: [
                                                                                                                                                                                                                    Positioned(
                                                                                                                                                                                                                      left: 5.175,
                                                                                                                                                                                                                      width: 173.325,
                                                                                                                                                                                                                      top: 0,
                                                                                                                                                                                                                      bottom: 0,
                                                                                                                                                                                                                      child: Container(
                                                                                                                                                                                                                        width: 173.325,
                                                                                                                                                                                                                        decoration: BoxDecoration(
                                                                                                                                                                                                                          border: Border.all(color: const Color(0xffe2e2e2), width: 1),
                                                                                                                                                                                                                          borderRadius: BorderRadius.circular(18),
                                                                                                                                                                                                                          boxShadow: const [BoxShadow(color: const Color(0x00000000), offset: Offset(0, 6), blurRadius: 12),],
                                                                                                                                                                                                                        ),
                                                                                                                                                                                                                      ),
                                                                                                                                                                                                                    ),
                                                                                                                                                                                                                    Positioned(
                                                                                                                                                                                                                      left: 19.562,
                                                                                                                                                                                                                      top: 125.048,
                                                                                                                                                                                                                      child: Text(
                                                                                                                                                                                                                        'كرتون ماي أبراج مع ثيم خاص',
                                                                                                                                                                                                                        textAlign: TextAlign.right,
                                                                                                                                                                                                                        style: TextStyle(decoration: TextDecoration.none, fontSize: 13, color: const Color(0xff181725), fontFamily: 'ElMessiri-Regular', fontWeight: FontWeight.normal),
                                                                                                                                                                                                                        maxLines: 9999,
                                                                                                                                                                                                                        overflow: TextOverflow.ellipsis,
                                                                                                                                                                                                                      ),
                                                                                                                                                                                                                    ),
                                                                                                                                                                                                                    Positioned(
                                                                                                                                                                                                                      left: 118.83,
                                                                                                                                                                                                                      width: 45.67,
                                                                                                                                                                                                                      bottom: 14.997999999999998,
                                                                                                                                                                                                                      height: 45.668,
                                                                                                                                                                                                                      child: Container(
                                                                                                                                                                                                                        width: 45.67,
                                                                                                                                                                                                                        height: 45.668,
                                                                                                                                                                                                                        decoration: BoxDecoration(
                                                                                                                                                                                                                          color: const Color(0xff53b175),
                                                                                                                                                                                                                          borderRadius: BorderRadius.circular(17),
                                                                                                                                                                                                                        ),
                                                                                                                                                                                                                      ),
                                                                                                                                                                                                                    ),
                                                                                                                                                                                                                    Positioned(
                                                                                                                                                                                                                      left: 20.175,
                                                                                                                                                                                                                      right: 4.125,
                                                                                                                                                                                                                      top: 152.951,
                                                                                                                                                                                                                      height: 14.893,
                                                                                                                                                                                                                      child: Text(
                                                                                                                                                                                                                        '20 حبة',
                                                                                                                                                                                                                        textAlign: TextAlign.left,
                                                                                                                                                                                                                        style: TextStyle(decoration: TextDecoration.none, fontSize: 14, color: const Color(0xff7c7c7c), fontFamily: 'ElMessiri-Regular', fontWeight: FontWeight.normal),
                                                                                                                                                                                                                        maxLines: 9999,
                                                                                                                                                                                                                        overflow: TextOverflow.ellipsis,
                                                                                                                                                                                                                      ),
                                                                                                                                                                                                                    ),
                                                                                                                                                                                                                    Positioned(
                                                                                                                                                                                                                      left: 5.125,
                                                                                                                                                                                                                      width: 173.325,
                                                                                                                                                                                                                      top: 0,
                                                                                                                                                                                                                      bottom: 0,
                                                                                                                                                                                                                      child: Container(
                                                                                                                                                                                                                        width: 173.325,
                                                                                                                                                                                                                        decoration: BoxDecoration(
                                                                                                                                                                                                                          border: Border.all(color: const Color(0xffe2e2e2), width: 1),
                                                                                                                                                                                                                          borderRadius: BorderRadius.circular(18),
                                                                                                                                                                                                                          boxShadow: const [BoxShadow(color: const Color(0x00000000), offset: Offset(0, 6), blurRadius: 12),],
                                                                                                                                                                                                                        ),
                                                                                                                                                                                                                      ),
                                                                                                                                                                                                                    ),
                                                                                                                                                                                                                    Positioned(
                                                                                                                                                                                                                      left: 20.562,
                                                                                                                                                                                                                      bottom: 25.46199999999999,
                                                                                                                                                                                                                      child: Text(
                                                                                                                                                                                                                        '5 KW',
                                                                                                                                                                                                                        textAlign: TextAlign.left,
                                                                                                                                                                                                                        style: TextStyle(decoration: TextDecoration.none, fontSize: 18, color: const Color(0xff181725), fontFamily: 'ElMessiri-Regular', fontWeight: FontWeight.normal),
                                                                                                                                                                                                                        maxLines: 9999,
                                                                                                                                                                                                                        overflow: TextOverflow.ellipsis,
                                                                                                                                                                                                                      ),
                                                                                                                                                                                                                    ),
                                                                                                                                                                                                                    Positioned(
                                                                                                                                                                                                                      left: 118.78,
                                                                                                                                                                                                                      width: 45.67,
                                                                                                                                                                                                                      top: 187.844,
                                                                                                                                                                                                                      height: 45.668,
                                                                                                                                                                                                                      child: Image.asset('images/imageImageview_660342.png', width: 45.67, height: 45.668,),
                                                                                                                                                                                                                    ),
                                                                                                                                                                                                                    Positioned(
                                                                                                                                                                                                                      left: 40.562,
                                                                                                                                                                                                                      width: 104,
                                                                                                                                                                                                                      top: 8.048,
                                                                                                                                                                                                                      height: 107,
                                                                                                                                                                                                                      child: Image.asset('images/imagePngfuel_660154.png', width: 104, height: 107, fit: BoxFit.fill,),
                                                                                                                                                                                                                    ),
                                                                                                                                                                                                                  ],
                                                                                                                                                                                                                ),
                                                                                                                                                                                                              ),
                                                                                                                                                                                                            ),
                                                                                                                                                                                                          ],
                                                                                                                                                                                                        ),
                                                                                                                                                                                                      ),
                                                                                                                                                                                                    ],
                                                                                                                                                                                                  ),
                                                                                                                                                                                                ),
                                                                                                                                                                                              ],
                                                                                                                                                                                            ),
                                                                                                                                                                                          ],
                                                                                                                                                                                        ),
                                                                                                                                                                                      ),
                                                                                                                                                                                    ),
                                                                                                                                                                                  ),
                                                                                                                                                                                ],
                                                                                                                                                                              ),
                                                                                                                                                                            ),
                                                                                                                                                                          ],
                                                                                                                                                                        ),
                                                                                                                                                                      ),
                                                                                                                                                                    ],
                                                                                                                                                                  ),
                                                                                                                                                                ],
                                                                                                                                                              ),
                                                                                                                                                            ),
                                                                                                                                                          ),
                                                                                                                                                        ],
                                                                                                                                                      ),
                                                                                                                                                    ),
                                                                                                                                                  ],
                                                                                                                                                ),
                                                                                                                                              ),
                                                                                                                                            ],
                                                                                                                                          ),
                                                                                                                                          const SizedBox(height: 29.999969482421875),
                                                                                                                                          Row(
                                                                                                                                            children: [
                                                                                                                                              Expanded(
                                                                                                                                                child: Row(
                                                                                                                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                                                                                                                  children: [
                                                                                                                                                    Expanded(
                                                                                                                                                      child: Row(
                                                                                                                                                        children: [
                                                                                                                                                          Expanded(
                                                                                                                                                            child: Container(
                                                                                                                                                              height: 38,
                                                                                                                                                              child: Stack(
                                                                                                                                                                children: [
                                                                                                                                                                  Positioned(
                                                                                                                                                                    left: 75.998,
                                                                                                                                                                    top: 0,
                                                                                                                                                                    bottom: 0,
                                                                                                                                                                    child: Text(
                                                                                                                                                                      'الكلينكس',
                                                                                                                                                                      textAlign: TextAlign.left,
                                                                                                                                                                      style: TextStyle(decoration: TextDecoration.none, fontSize: 24, color: const Color(0xff181725), fontFamily: 'ElMessiri-Regular', fontWeight: FontWeight.normal),
                                                                                                                                                                      maxLines: 9999,
                                                                                                                                                                      overflow: TextOverflow.ellipsis,
                                                                                                                                                                    ),
                                                                                                                                                                  ),
                                                                                                                                                                  Positioned(
                                                                                                                                                                    left: 389.997,
                                                                                                                                                                    top: 4.5,
                                                                                                                                                                    bottom: 8.5,
                                                                                                                                                                    child: Text(
                                                                                                                                                                      'See all',
                                                                                                                                                                      textAlign: TextAlign.left,
                                                                                                                                                                      style: TextStyle(decoration: TextDecoration.none, fontSize: 16, color: const Color(0xff104fc9), fontFamily: 'ElMessiri-Regular', fontWeight: FontWeight.normal),
                                                                                                                                                                      maxLines: 9999,
                                                                                                                                                                      overflow: TextOverflow.ellipsis,
                                                                                                                                                                    ),
                                                                                                                                                                  ),
                                                                                                                                                                ],
                                                                                                                                                              ),
                                                                                                                                                            ),
                                                                                                                                                          ),
                                                                                                                                                        ],
                                                                                                                                                      ),
                                                                                                                                                    ),
                                                                                                                                                  ],
                                                                                                                                                ),
                                                                                                                                              ),
                                                                                                                                            ],
                                                                                                                                          ),
                                                                                                                                        ],
                                                                                                                                      ),
                                                                                                                                    ),
                                                                                                                                  ),
                                                                                                                                ],
                                                                                                                              ),
                                                                                                                            ),
                                                                                                                          ],
                                                                                                                        ),
                                                                                                                      ),
                                                                                                                    ],
                                                                                                                  ),
                                                                                                                ],
                                                                                                              ),
                                                                                                            ),
                                                                                                          ),
                                                                                                        ],
                                                                                                      ),
                                                                                                    ),
                                                                                                  ],
                                                                                                ),
                                                                                              ),
                                                                                            ],
                                                                                          ),
                                                                                        ],
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                            ),
                                                                          ],
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 11.28338623046875),
                  Row(
                    children: [
                      Expanded(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Expanded(
                              child: Row(
                                children: [
                                  Expanded(
                                    child: Container(
                                      height: 248.51,
                                      child: Stack(
                                        children: [
                                          Positioned(
                                            left: 126.351,
                                            width: 173.325,
                                            top: 0,
                                            bottom: 0,
                                            child: Container(
                                              width: 173.325,
                                              decoration: BoxDecoration(
                                                border: Border.all(color: const Color(0xffe2e2e2), width: 1),
                                                borderRadius: BorderRadius.circular(18),
                                                boxShadow: const [BoxShadow(color: const Color(0x00000000), offset: Offset(0, 6), blurRadius: 12),],
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            left: 10,
                                            width: 294.851,
                                            bottom: 14.997999999999998,
                                            height: 45.668,
                                            child: Stack(
                                              children: [
                                                Positioned(
                                                  left: 131.351,
                                                  top: 16.798,
                                                  bottom: 10.870000000000001,
                                                  child: Text(
                                                    '1 KW',
                                                    textAlign: TextAlign.left,
                                                    style: TextStyle(decoration: TextDecoration.none, fontSize: 18, color: const Color(0xff181725), fontFamily: 'ElMessiri-Regular', fontWeight: FontWeight.normal),
                                                    maxLines: 9999,
                                                    overflow: TextOverflow.ellipsis,
                                                  ),
                                                ),
                                                Positioned(
                                                  right: 19.174999999999997,
                                                  width: 45.67,
                                                  top: 0,
                                                  height: 45.668,
                                                  child: Image.asset('images/imageGroup_660343.png', width: 45.67, height: 45.668,),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Positioned(
                                            left: 314.851,
                                            width: 173.325,
                                            top: 0,
                                            bottom: 0,
                                            child: Container(
                                              width: 173.325,
                                              decoration: BoxDecoration(
                                                border: Border.all(color: const Color(0xffe2e2e2), width: 1),
                                                borderRadius: BorderRadius.circular(18),
                                                boxShadow: const [BoxShadow(color: const Color(0x00000000), offset: Offset(0, 6), blurRadius: 12),],
                                              ),
                                            ),
                                          ),
                                          Positioned(
                                            right: 30.000999999999976,
                                            width: 291.731,
                                            bottom: 14.997999999999998,
                                            height: 45.668,
                                            child: Stack(
                                              children: [
                                                Positioned(
                                                  left: 15,
                                                  top: 16.798,
                                                  bottom: 10.870000000000001,
                                                  child: Text(
                                                    '1 KW',
                                                    textAlign: TextAlign.left,
                                                    style: TextStyle(decoration: TextDecoration.none, fontSize: 18, color: const Color(0xff181725), fontFamily: 'ElMessiri-Regular', fontWeight: FontWeight.normal),
                                                    maxLines: 9999,
                                                    overflow: TextOverflow.ellipsis,
                                                  ),
                                                ),
                                                Positioned(
                                                  left: 113.655,
                                                  width: 45.67,
                                                  top: 0,
                                                  height: 45.668,
                                                  child: Image.asset('images/imageGroup_660344.png', width: 45.67, height: 45.668,),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Positioned(
                                            left: 100.998,
                                            width: 414,
                                            bottom: 85.255,
                                            height: 92,
                                            child: Container(
                                              width: 414,
                                              height: 92,
                                              decoration: BoxDecoration(
                                                color: const Color(0xffffffff),
                                                boxShadow: const [BoxShadow(color: const Color(0x16545d58), offset: Offset(2, -5), blurRadius: 15),],
                                              ),
                                              child: Padding(
                                                padding: const EdgeInsets.only(left: 10, top: 0, right: 10, bottom: 12.795440673828125),
                                                child: Row(
                                                  mainAxisAlignment: MainAxisAlignment.center,
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  children: [
                                                    Expanded(
                                                      child: Column(
                                                        mainAxisAlignment: MainAxisAlignment.center,
                                                        mainAxisSize: MainAxisSize.max,
                                                        children: [
                                                          Expanded(
                                                            child: Container(
                                                              width: double.infinity,
                                                              height: 46.168,
                                                              child: Stack(
                                                                children: [
                                                                  Positioned(
                                                                    left: 15.241,
                                                                    right: 24.120000000000005,
                                                                    top: 0,
                                                                    bottom: 0,
                                                                    child: Stack(
                                                                      children: [
                                                                        Positioned(
                                                                          left: 153.449,
                                                                          width: 28,
                                                                          top: 2.437,
                                                                          height: 43.731,
                                                                          child: Stack(
                                                                            children: [
                                                                              Row(
                                                                                mainAxisAlignment: MainAxisAlignment.center,
                                                                                children: [
                                                                                  Positioned(
                                                                                    left: 3.015,
                                                                                    width: 21.97,
                                                                                    top: 0,
                                                                                    height: 19.563,
                                                                                    child: Image.asset('images/imageVector_660162.png', width: 21.97, height: 19.563,),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                              const SizedBox(height: 5.1684417724609375),
                                                                              Row(
                                                                                children: [
                                                                                  Expanded(
                                                                                    child: Row(
                                                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                                                      mainAxisSize: MainAxisSize.min,
                                                                                      children: [
                                                                                        Expanded(
                                                                                          child: Positioned(
                                                                                            left: 0,
                                                                                            right: 0,
                                                                                            top: 24.731,
                                                                                            child: Container(
                                                                                              child: Text(
                                                                                                'السلة',
                                                                                                textAlign: TextAlign.center,
                                                                                                style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xff181725), fontFamily: 'ElMessiri-Regular', fontWeight: FontWeight.normal),
                                                                                                maxLines: 9999,
                                                                                                overflow: TextOverflow.ellipsis,
                                                                                              ),
                                                                                            ),
                                                                                          ),
                                                                                        ),
                                                                                      ],
                                                                                    ),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                            ],
                                                                          ),
                                                                        ),
                                                                        Positioned(
                                                                          right: 48,
                                                                          width: 115.19,
                                                                          top: 0,
                                                                          height: 46.168,
                                                                          child: Padding(
                                                                            padding: const EdgeInsets.only(left: 0, top: 0, right: 5, bottom: 0),
                                                                            child: Stack(
                                                                              children: [
                                                                                Row(
                                                                                  mainAxisAlignment: MainAxisAlignment.center,
                                                                                  children: [
                                                                                    Positioned(
                                                                                      left: 43.095,
                                                                                      width: 24,
                                                                                      top: 0,
                                                                                      height: 24,
                                                                                      child: Image.asset('images/imageBookmark_660174.png', width: 24, height: 24,),
                                                                                    ),
                                                                                  ],
                                                                                ),
                                                                                const SizedBox(height: 2.686492919921875),
                                                                                Row(
                                                                                  children: [
                                                                                    Expanded(
                                                                                      child: Row(
                                                                                        mainAxisAlignment: MainAxisAlignment.start,
                                                                                        mainAxisSize: MainAxisSize.min,
                                                                                        children: [
                                                                                          Expanded(
                                                                                            child: Positioned(
                                                                                              left: 0,
                                                                                              right: 5,
                                                                                              top: 26.686,
                                                                                              child: Container(
                                                                                                child: Text(
                                                                                                  'المفضلة',
                                                                                                  textAlign: TextAlign.center,
                                                                                                  style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xff181725), fontFamily: 'ElMessiri-Regular', fontWeight: FontWeight.normal),
                                                                                                  maxLines: 9999,
                                                                                                  overflow: TextOverflow.ellipsis,
                                                                                                ),
                                                                                              ),
                                                                                            ),
                                                                                          ),
                                                                                        ],
                                                                                      ),
                                                                                    ),
                                                                                  ],
                                                                                ),
                                                                              ],
                                                                            ),
                                                                          ),
                                                                        ),
                                                                        Positioned(
                                                                          right: 0,
                                                                          width: 38,
                                                                          top: 0,
                                                                          height: 46.168,
                                                                          child: Stack(
                                                                            children: [
                                                                              Row(
                                                                                mainAxisAlignment: MainAxisAlignment.center,
                                                                                children: [
                                                                                  Positioned(
                                                                                    left: 7,
                                                                                    width: 24,
                                                                                    top: 0,
                                                                                    height: 24,
                                                                                    child: Image.asset('images/imageUser_660178.png', width: 24, height: 24,),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                              const SizedBox(height: 3.168426513671875),
                                                                              Row(
                                                                                children: [
                                                                                  Expanded(
                                                                                    child: Row(
                                                                                      mainAxisAlignment: MainAxisAlignment.start,
                                                                                      mainAxisSize: MainAxisSize.min,
                                                                                      children: [
                                                                                        Expanded(
                                                                                          child: Positioned(
                                                                                            left: 0,
                                                                                            right: 0,
                                                                                            top: 27.168,
                                                                                            child: Container(
                                                                                              child: Text(
                                                                                                'الحساب',
                                                                                                textAlign: TextAlign.center,
                                                                                                style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xff181725), fontFamily: 'ElMessiri-Regular', fontWeight: FontWeight.normal),
                                                                                                maxLines: 9999,
                                                                                                overflow: TextOverflow.ellipsis,
                                                                                              ),
                                                                                            ),
                                                                                          ),
                                                                                        ),
                                                                                      ],
                                                                                    ),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                            ],
                                                                          ),
                                                                        ),
                                                                        Positioned(
                                                                          left: 0,
                                                                          width: 40.848,
                                                                          top: 0,
                                                                          height: 44.482,
                                                                          child: Stack(
                                                                            children: [
                                                                              Row(
                                                                                mainAxisAlignment: MainAxisAlignment.center,
                                                                                children: [
                                                                                  Positioned(
                                                                                    left: 8.424,
                                                                                    width: 24,
                                                                                    top: 0,
                                                                                    height: 24,
                                                                                    child: Image.asset('images/imageStore_660164.png', width: 24, height: 24,),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                              const SizedBox(height: 3.48193359375),
                                                                              Row(
                                                                                children: [
                                                                                  Expanded(
                                                                                    child: Positioned(
                                                                                      left: 0,
                                                                                      right: 0,
                                                                                      top: 27.482,
                                                                                      child: Container(
                                                                                        child: Text(
                                                                                          'الرئيسية',
                                                                                          textAlign: TextAlign.center,
                                                                                          style: TextStyle(decoration: TextDecoration.none, fontSize: 11, color: const Color(0xff104fc9), fontFamily: 'ElMessiri-Regular', fontWeight: FontWeight.normal),
                                                                                          maxLines: 9999,
                                                                                          overflow: TextOverflow.ellipsis,
                                                                                        ),
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                            ],
                                                                          ),
                                                                        ),
                                                                        Positioned(
                                                                          left: 50.848,
                                                                          width: 87.36,
                                                                          top: 3.719,
                                                                          height: 42.449,
                                                                          child: Padding(
                                                                            padding: const EdgeInsets.only(left: 0, top: 0, right: 0.348052978515625, bottom: 0),
                                                                            child: Stack(
                                                                              children: [
                                                                                Row(
                                                                                  mainAxisAlignment: MainAxisAlignment.center,
                                                                                  children: [
                                                                                    Positioned(
                                                                                      left: 29.331,
                                                                                      width: 28.349,
                                                                                      top: 0,
                                                                                      height: 18.205,
                                                                                      child: Image.asset('images/imageGroup_660346.png', width: 28.349, height: 18.205,),
                                                                                    ),
                                                                                  ],
                                                                                ),
                                                                                const SizedBox(height: 5.244163513183594),
                                                                                Row(
                                                                                  children: [
                                                                                    Expanded(
                                                                                      child: Row(
                                                                                        mainAxisAlignment: MainAxisAlignment.start,
                                                                                        mainAxisSize: MainAxisSize.min,
                                                                                        children: [
                                                                                          Expanded(
                                                                                            child: Positioned(
                                                                                              left: 0,
                                                                                              right: 0.347999999999999,
                                                                                              top: 23.449,
                                                                                              child: Container(
                                                                                                child: Text(
                                                                                                  'الأقسام',
                                                                                                  textAlign: TextAlign.center,
                                                                                                  style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xff181725), fontFamily: 'ElMessiri-Regular', fontWeight: FontWeight.normal),
                                                                                                  maxLines: 9999,
                                                                                                  overflow: TextOverflow.ellipsis,
                                                                                                ),
                                                                                              ),
                                                                                            ),
                                                                                          ),
                                                                                        ],
                                                                                      ),
                                                                                    ),
                                                                                  ],
                                                                                ),
                                                                              ],
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
